# King AI — Android starter configured for the existing King Supabase project

This project targets the existing **King** project, not King2.
- Supabase URL: `https://zmtaszydqeagtnslcrgv.supabase.co`
- Android client uses the project's publishable key. A publishable key is designed for client apps; never put a service-role key or AI-provider secret in an APK.

## What is configured
- Kotlin + Jetpack Compose Android project
- King AI chat interface, light/dark toggle, new chat
- Email/password signup and login through Supabase Auth
- Authenticated call to the existing `ai-chat` Edge Function in King
- Saves each user and assistant message to the existing `public.chat_messages` table
- Loads the latest conversation after login and provides a Chat History list to reopen saved conversations
- Adds a `conversation_id` UUID column and index to `public.chat_messages` so separate chats remain grouped; existing rows receive a generated conversation ID
- Reads/writes are scoped by the signed-in user and depend on the table’s existing Row Level Security policies.

## AI provider requirement
The currently deployed `King` `ai-chat` function calls the OpenAI Responses API and expects the `OPENAI_API_KEY` secret in **King → Edge Functions → Secrets**. I cannot read the secret value through the project listing, so verify it is configured in the dashboard. OpenAI API use is not automatically free just because the Supabase project is free. Do not put the provider secret into this Android app or send it in chat.

## Build APK
Open this folder in Android Studio with JDK 17 and Android SDK 35 installed, let Gradle sync, then run:
```bash
./gradlew assembleDebug
```
Windows:
```bat
gradlew.bat assembleDebug
```
Expected APK path after a successful build: `app/build/outputs/apk/debug/app-debug.apk`.

## Status / limitations
This source has been configured for the King project, but it has **not been compiled or end-to-end tested** in this environment because Android SDK/Gradle are unavailable. Chat history wiring has been added to the source but has not been compiled or end-to-end tested in this environment. The migration `002_chat_conversation_history.sql` has also been applied to the King Supabase project. Before release, test signup, email-confirmation behavior, login, API secrets, chat save/load, network errors, and account isolation.

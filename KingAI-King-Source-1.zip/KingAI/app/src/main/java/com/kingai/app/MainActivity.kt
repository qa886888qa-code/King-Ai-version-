package com.kingai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KingAiApp() }
    }
}

data class ChatMessage(val role: String, val content: String)
data class AuthSession(val accessToken: String, val userId: String)
data class ChatSummary(val id: String, val title: String, val updatedAt: String)

private val http = OkHttpClient()
private val jsonType = "application/json; charset=utf-8".toMediaType()
private const val GREETING = "Assalam-o-alaikum! Main King AI hoon. Apna sawal likhein."

@Composable
fun KingAiApp() {
    var token by remember { mutableStateOf<String?>(null) }
    var userId by remember { mutableStateOf<String?>(null) }
    var email by remember { mutableStateOf("") }
    var dark by remember { mutableStateOf(true) }
    MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = Color(0xFF8B9CFF), background = Color(0xFF10121A), surface = Color(0xFF1B1E29)) else lightColorScheme(primary = Color(0xFF4054B2))) {
        if (token == null || userId == null) {
            AuthScreen(onAuthenticated = { access, id, mail -> token = access; userId = id; email = mail }, dark = dark, onTheme = { dark = !dark })
        } else {
            ChatScreen(token = token!!, userId = userId!!, email = email, dark = dark, onTheme = { dark = !dark }, onLogout = { token = null; userId = null; email = "" })
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthScreen(onAuthenticated: (String, String, String) -> Unit, dark: Boolean, onTheme: () -> Unit) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var createAccount by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    Scaffold(topBar = { TopAppBar(title = { Text("King AI", fontWeight = FontWeight.Bold) }, actions = { TextButton(onClick = onTheme) { Text(if (dark) "Light" else "Dark") } }) }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Text(if (createAccount) "Create your account" else "Welcome back", fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("Sign in securely to use King AI", color = MaterialTheme.colorScheme.onSurface.copy(alpha = .7f))
            Spacer(Modifier.height(24.dp))
            OutlinedTextField(email, { email = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Email") }, singleLine = true)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(password, { password = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Password") }, singleLine = true)
            error?.let { Spacer(Modifier.height(8.dp)); Text(it, color = MaterialTheme.colorScheme.error) }
            Spacer(Modifier.height(16.dp))
            Button(onClick = {
                if (!email.contains("@") || password.length < 6) { error = "Valid email aur kam az kam 6-character password enter karein."; return@Button }
                busy = true; error = null
                scope.launch {
                    try {
                        val session = withContext(Dispatchers.IO) { authenticate(email.trim(), password, createAccount) }
                        if (session.accessToken.isBlank() || session.userId.isBlank()) error = "Account ban gaya. Agar email confirmation enabled hai to inbox check karke phir login karein."
                        else onAuthenticated(session.accessToken, session.userId, email.trim())
                    } catch (e: Exception) { error = e.message ?: "Login error. Internet check karein." }
                    finally { busy = false }
                }
            }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                Text(if (busy) "Please wait…" else if (createAccount) "Create account" else "Login")
            }
            TextButton(onClick = { createAccount = !createAccount; error = null }) { Text(if (createAccount) "Already registered? Login" else "New here? Create account") }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(token: String, userId: String, email: String, dark: Boolean, onTheme: () -> Unit, onLogout: () -> Unit) {
    val messages = remember { mutableStateListOf<ChatMessage>() }
    var conversationId by remember { mutableStateOf(UUID.randomUUID().toString()) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var history by remember { mutableStateOf<List<ChatSummary>>(emptyList()) }
    var showHistory by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(token, userId) {
        busy = true
        try {
            val recent = withContext(Dispatchers.IO) { loadChatHistory(token, userId) }
            history = recent
            if (recent.isNotEmpty()) {
                conversationId = recent.first().id
                val loaded = withContext(Dispatchers.IO) { loadMessages(token, userId, conversationId) }
                messages.clear(); messages.addAll(loaded)
                if (messages.isEmpty()) messages.add(ChatMessage("assistant", GREETING))
            } else {
                messages.clear(); messages.add(ChatMessage("assistant", GREETING))
            }
        } catch (e: Exception) {
            messages.clear(); messages.add(ChatMessage("assistant", GREETING))
            error = "History load nahi hui: ${e.message ?: "network error"}"
        } finally { busy = false }
    }

    fun startNewChat() {
        conversationId = UUID.randomUUID().toString()
        messages.clear(); messages.add(ChatMessage("assistant", "Nayi chat shuru ho gayi. Apna sawal likhein."))
        error = null
    }

    fun openConversation(summary: ChatSummary) {
        showHistory = false
        busy = true; error = null
        scope.launch {
            try {
                val loaded = withContext(Dispatchers.IO) { loadMessages(token, userId, summary.id) }
                conversationId = summary.id
                messages.clear()
                if (loaded.isEmpty()) messages.add(ChatMessage("assistant", GREETING)) else messages.addAll(loaded)
            } catch (e: Exception) { error = "Chat load nahi hui: ${e.message ?: "network error"}" }
            finally { busy = false }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Column { Text("King AI", fontWeight = FontWeight.Bold); Text(email, fontSize = 11.sp) } }, actions = {
                IconButton(onClick = { showHistory = true; scope.launch { try { history = withContext(Dispatchers.IO) { loadChatHistory(token, userId) } } catch (e: Exception) { error = e.message } } }) { Icon(Icons.Default.History, contentDescription = "Chat history") }
                IconButton(onClick = { startNewChat() }) { Icon(Icons.Default.Add, contentDescription = "New chat") }
                TextButton(onClick = onTheme) { Text(if (dark) "Light" else "Dark") }
                TextButton(onClick = onLogout) { Text("Logout") }
            })
        },
        bottomBar = {
            Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(10.dp)) {
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), placeholder = { Text("Message King AI…") }, maxLines = 5, enabled = !busy)
                    Spacer(Modifier.width(8.dp))
                    IconButton(enabled = input.isNotBlank() && !busy, onClick = {
                        val prompt = input.trim(); input = ""; messages.add(ChatMessage("user", prompt)); busy = true; error = null
                        scope.launch {
                            try {
                                withContext(Dispatchers.IO) { saveMessage(token, userId, conversationId, "user", prompt) }
                                val contextMessages = messages.filter { it.role == "user" || it.role == "assistant" }
                                val answer = withContext(Dispatchers.IO) { callBackend(contextMessages, token) }
                                withContext(Dispatchers.IO) { saveMessage(token, userId, conversationId, "assistant", answer) }
                                messages.add(ChatMessage("assistant", answer))
                                history = withContext(Dispatchers.IO) { loadChatHistory(token, userId) }
                            } catch (e: Exception) { error = e.message ?: "Network error. Internet check karein." }
                            finally { busy = false }
                        }
                    }) { Icon(Icons.Default.Send, contentDescription = "Send") }
                }
                Text("Chat history automatically sync hoti hai.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha=.65f))
            }
        }
    ) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 12.dp), contentPadding = PaddingValues(vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(messages) { msg ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.role == "user") Arrangement.End else Arrangement.Start) {
                    Surface(color = if (msg.role == "user") MaterialTheme.colorScheme.primary.copy(alpha=.22f) else MaterialTheme.colorScheme.surface, shape = RoundedCornerShape(18.dp), modifier = Modifier.widthIn(max = 330.dp)) {
                        Text(msg.content, Modifier.padding(14.dp), color = MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
            if (busy) item { Text("Loading / King AI is thinking…", color = MaterialTheme.colorScheme.onSurface.copy(alpha=.7f)) }
        }
    }

    if (showHistory) {
        AlertDialog(
            onDismissRequest = { showHistory = false },
            title = { Text("Chat history") },
            text = {
                if (history.isEmpty()) Text("Abhi koi saved chat nahi. Naya message bhejne par history save ho jayegi.")
                else LazyColumn(modifier = Modifier.heightIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(history, key = { it.id }) { item ->
                        TextButton(onClick = { openConversation(item) }, modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.fillMaxWidth()) {
                                Text(item.title, maxLines = 2, color = MaterialTheme.colorScheme.onSurface)
                                Text(item.updatedAt, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .6f))
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showHistory = false }) { Text("Close") } },
            dismissButton = { TextButton(onClick = { startNewChat(); showHistory = false }) { Text("New chat") } }
        )
    }
}

private fun authenticate(email: String, password: String, signup: Boolean): AuthSession {
    val endpoint = if (signup) "/auth/v1/signup" else "/auth/v1/token?grant_type=password"
    val body = JSONObject().put("email", email).put("password", password).toString().toRequestBody(jsonType)
    val request = Request.Builder().url(BuildConfig.SUPABASE_URL + endpoint)
        .addHeader("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY).addHeader("Content-Type", "application/json").post(body).build()
    http.newCall(request).execute().use { response ->
        val raw = response.body?.string().orEmpty()
        val obj = try { JSONObject(raw) } catch (_: Exception) { JSONObject() }
        if (!response.isSuccessful) throw IllegalStateException(obj.optString("msg", obj.optString("message", obj.optJSONObject("error")?.optString("message") ?: "Authentication failed (${response.code}).")))
        return AuthSession(obj.optString("access_token"), obj.optJSONObject("user")?.optString("id").orEmpty())
    }
}

private fun authRequestBuilder(path: String, token: String): Request.Builder = Request.Builder()
    .url(BuildConfig.SUPABASE_URL.trimEnd('/') + path)
    .addHeader("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
    .addHeader("Authorization", "Bearer $token")
    .addHeader("Content-Type", "application/json")

private fun saveMessage(token: String, userId: String, conversationId: String, role: String, content: String) {
    val payload = JSONObject().put("user_id", userId).put("conversation_id", conversationId).put("role", role).put("content", content)
        .toString().toRequestBody(jsonType)
    val request = authRequestBuilder("/rest/v1/chat_messages", token)
        .addHeader("Prefer", "return=minimal").post(payload).build()
    http.newCall(request).execute().use { response ->
        val raw = response.body?.string().orEmpty()
        if (!response.isSuccessful) {
            val obj = try { JSONObject(raw) } catch (_: Exception) { JSONObject() }
            throw IllegalStateException(obj.optString("message", obj.optString("error", "Chat save failed (${response.code}).")))
        }
    }
}

private fun loadMessages(token: String, userId: String, conversationId: String): List<ChatMessage> {
    val path = "/rest/v1/chat_messages?select=role,content,created_at&user_id=eq.$userId&conversation_id=eq.$conversationId&order=created_at.asc&limit=500"
    val request = authRequestBuilder(path, token).get().build()
    http.newCall(request).execute().use { response ->
        val raw = response.body?.string().orEmpty()
        if (!response.isSuccessful) throw IllegalStateException("Chat history load failed (${response.code}): $raw")
        val arr = JSONArray(raw)
        return (0 until arr.length()).map { i -> arr.getJSONObject(i).let { ChatMessage(it.optString("role"), it.optString("content")) } }
    }
}

private fun loadChatHistory(token: String, userId: String): List<ChatSummary> {
    val path = "/rest/v1/chat_messages?select=conversation_id,role,content,created_at&user_id=eq.$userId&order=created_at.desc&limit=300"
    val request = authRequestBuilder(path, token).get().build()
    http.newCall(request).execute().use { response ->
        val raw = response.body?.string().orEmpty()
        if (!response.isSuccessful) throw IllegalStateException("Chat list load failed (${response.code}): $raw")
        val arr = JSONArray(raw)
        val summaries = linkedMapOf<String, ChatSummary>()
        for (i in 0 until arr.length()) {
            val row = arr.getJSONObject(i)
            val id = row.optString("conversation_id")
            if (id.isBlank() || id == "null") continue
            val content = row.optString("content").replace('\n', ' ').trim()
            val role = row.optString("role")
            val existing = summaries[id]
            if (existing == null) {
                val title = if (role == "user" && content.isNotBlank()) content.take(64) else "King AI conversation"
                summaries[id] = ChatSummary(id, title, row.optString("created_at").replace('T', ' ').take(16))
            } else if (existing.title == "King AI conversation" && role == "user" && content.isNotBlank()) {
                summaries[id] = existing.copy(title = content.take(64))
            }
        }
        return summaries.values.toList()
    }
}

private fun callBackend(messages: List<ChatMessage>, token: String): String {
    val arr = JSONArray()
    messages.filter { it.role == "user" || it.role == "assistant" }.takeLast(16).forEach { arr.put(JSONObject().put("role", it.role).put("content", it.content)) }
    val payload = JSONObject().put("system", "You are King AI, a helpful AI assistant. Reply in the language the user uses, including Urdu, Roman Urdu, Hindi, and English. Be clear, accurate, and honest.").put("messages", arr).toString().toRequestBody(jsonType)
    val request = Request.Builder().url(BuildConfig.SUPABASE_URL.trimEnd('/') + "/functions/v1/ai-chat")
        .addHeader("apikey", BuildConfig.SUPABASE_PUBLISHABLE_KEY)
        .addHeader("Authorization", "Bearer $token").addHeader("Content-Type", "application/json").post(payload).build()
    http.newCall(request).execute().use { response ->
        val raw = response.body?.string().orEmpty()
        val obj = try { JSONObject(raw) } catch (_: Exception) { JSONObject() }
        if (!response.isSuccessful) throw IllegalStateException(obj.optString("error", obj.optString("msg", "Request failed (${response.code}).")))
        return obj.optString("text").ifBlank { "AI provider returned an empty response." }
    }
}

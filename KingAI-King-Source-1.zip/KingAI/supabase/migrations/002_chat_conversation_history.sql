-- Adds stable conversation grouping to the existing King chat_messages table.
alter table public.chat_messages
  add column if not exists conversation_id uuid not null default gen_random_uuid();

create index if not exists chat_messages_user_conversation_created_idx
  on public.chat_messages (user_id, conversation_id, created_at);

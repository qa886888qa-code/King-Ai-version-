import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json"
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const key = Deno.env.get("OPENAI_API_KEY");
    if (!key) return new Response(JSON.stringify({error:"OPENAI_API_KEY is not configured in Supabase Secrets."}), {status:500,headers:cors});
    const body = await req.json();
    const messages = Array.isArray(body.messages) ? body.messages.slice(-20) : [];
    const system = body.system || "You are King AI, a helpful assistant. Support Urdu, Roman Urdu, Hindi and English. Answer clearly, accurately and concisely.";
    const response = await fetch("https://api.openai.com/v1/responses", {
      method:"POST",
      headers:{"Content-Type":"application/json","Authorization":`Bearer ${key}`},
      body:JSON.stringify({model:body.model || "gpt-5-mini",input:[{role:"system",content:system}, ...messages.map((m:any)=>({role:m.role,content:m.content}))],max_output_tokens:1200})
    });
    const data = await response.json();
    if (!response.ok) return new Response(JSON.stringify({error:data?.error?.message || "AI request failed"}), {status:response.status,headers:cors});
    return new Response(JSON.stringify({text:data.output_text || ""}), {headers:cors});
  } catch (e) {
    return new Response(JSON.stringify({error:e instanceof Error ? e.message : "Unexpected error"}), {status:500,headers:cors});
  }
});
